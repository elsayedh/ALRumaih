Odoo - Payroll Anaylitic Account
========================================

When enabled in an specific Salary Rule it uses the Analytic Account selected in the Employees Contract
You can check functionality in the following video:

https://www.youtube.com/watch?v=raLA72Sfcds

## Credits
<p>
<img width="200" alt="Logo Konos" src="https://www.konos.cl/web/image/res.company/1/logo?unique=445cd30" />
</p>
**Konos** - http://konos.cl
 - Nelson Ramírez <info@konos.cl>


 
 **Contributors**
 - Daniel Blanco Martín <daniel@blancomartin.com>
 - Carlos Lopez Mite <celm1990@hotmail.com>
